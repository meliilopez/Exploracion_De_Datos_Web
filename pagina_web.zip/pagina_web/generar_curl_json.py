import subprocess, json, time
from pathlib import Path

BASE = Path("mi_sitio")
ASSETS = BASE / "assets"
ASSETS.mkdir(parents=True, exist_ok=True)

TARGETS = [
    {"name": "GitHub API", "url": "https://api.github.com/"},
    {"name": "JSONPlaceholder", "url": "https://jsonplaceholder.typicode.com/todos/1"},
    {"name": "HTTPBin", "url": "https://httpbin.org/get"},
    {"name": "PokeAPI", "url": "https://pokeapi.co/api/v2/pokemon/ditto"},
    {"name": "CatFact", "url": "https://catfact.ninja/fact"},
]

def curl_headers(url: str):
    """
    Usa curl para obtener solo encabezados (-D -) y descartar cuerpo (-o /dev/null).
    Toma el último bloque de headers (por si hay redirecciones).
    """
    t0 = time.time()
    try:
        cmd = ["curl", "-sS", "-D", "-", "-o", "/dev/null", url]
        try:
            out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, timeout=25)
        except Exception:
            cmd = ["curl", "-sS", "-D", "-", "-o", "nul", url]  # fallback Windows
            out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, timeout=25)

        ms = int((time.time() - t0) * 1000)
        text = out.decode("utf-8", errors="replace")

        # Normalizamos saltos de linea y tomamos el ultimo bloque de headers
        blocks = text.replace("\r\n", "\n").strip().split("\n\n")
        last = blocks[-1] if blocks else ""
        lines = [ln for ln in last.split("\n") if ln.strip()]

        if not lines:
            return {"ok": False, "error": "Sin headers", "ms": ms}

        status_line = lines[0]
        headers = {}
        for line in lines[1:]:
            if ":" in line:
                k, v = line.split(":", 1)
                headers[k.strip().lower()] = v.strip()

        # Extraer código de estado
        import re
        m = re.search(r"HTTP/\d(?:\.\d)?\s+(\d+)", status_line)
        code = int(m.group(1)) if m else None

        return {"ok": True, "status": code, "ms": ms, "headers": headers}
    except Exception as e:
        return {"ok": False, "error": str(e)}

results = []
for t in TARGETS:
    r = curl_headers(t["url"])
    results.append({"name": t["name"], "url": t["url"], **r})

outpath = ASSETS / "curl_results.json"
outpath.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"Generado: {outpath.resolve()}")
