import os
from pathlib import Path

# Carpeta destino
BASE = Path("mi_sitio")
(BASE / "assets").mkdir(parents=True, exist_ok=True)

CSS = """body{font-family:sans-serif;background:#0f172a;color:#e6eef8;padding:20px}
.container{max-width:960px;margin:0 auto}
.header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}
.nav a{margin:0 10px;color:#94a3b8;text-decoration:none}
.nav a.active{color:#fff}
.card{padding:20px;background:#1e293b;border-radius:10px;margin:20px 0}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px}
.feature{background:#0f172a;padding:10px;border:1px solid #334155;border-radius:8px}
/* Botón ahora en verde */
.cta{display:inline-block;margin-top:10px;padding:10px;background:#22c55e;color:#fff;border-radius:6px;text-decoration:none;font-weight:600}
.cta:hover{filter:brightness(1.1)}
.footer{margin-top:20px;text-align:center;font-size:.85rem;color:#94a3b8}
.small{font-size:.9rem;color:#94a3b8}
/* Logo como imagen (reemplaza al círculo KF) */
.logo-img{width:44px;height:44px;object-fit:contain;display:block;margin-right:10px}
.brand{display:flex;align-items:center;gap:10px}
"""


# --- Página: INICIO ---
index_html = """<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Kiosco y Fotocopiadora Facultad de Ingeniería UNER</title>
  <link rel="stylesheet" href="assets/styles.css">
</head>
<body>
  <div class="container">
    <header class="header">
      <div class="brand">
        <img class="logo-img" src="assets/logo.png" alt="Kiosco y Fotocopiadora">
        <div>
          <h1 style="font-size:1.15rem;margin-bottom:2px">Kiosco y Fotocopiadora</h1>
          <div class="small">Facultad de Ingeniería UNER</div>
        </div>
      </div>
      <nav class="nav" aria-label="Navegación principal">
        <a href="index.html" class="active">Inicio</a>
        <a href="products.html">Productos</a>
        <a href="postulaciones.html">Postulaciones</a>
        <a href="contact.html">Contacto</a>
        <a href="servidores.html">Servidores</a>
      </nav>
    </header>
    <main>
      <section class="card">
        <h2>Bienvenidos</h2>
        <p class="small">Kiosco y Fotocopiadora de la Facultad de Ingeniería UNER.</p>
        <ul>
          <li><strong>Dirección:</strong> RP11, Oro Verde, Entre Ríos</li>
          <li><strong>Horario:</strong> 08:00 a 19:00 hs</li>
        </ul>
      </section>
    </main>
    <footer class="footer">© 2025 Kiosco y Fotocopiadora - Facultad de Ingeniería UNER</footer>
  </div>
</body>
</html>
"""

# --- Página: PRODUCTOS ---
products_html = """<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Productos — Kiosco y Fotocopiadora FI-UNER</title>
  <link rel="stylesheet" href="assets/styles.css">
</head>
<body>
  <div class="container">
    <header class="header">
      <div class="brand">
        <img class="logo-img" src="assets/logo.png" alt="Kiosco y Fotocopiadora">
        <div>
          <h1 style="font-size:1.15rem;margin-bottom:2px">Kiosco y Fotocopiadora</h1>
          <div class="small">Facultad de Ingeniería UNER</div>
        </div>
      </div>
      <nav class="nav" aria-label="Navegación principal">
        <a href="index.html">Inicio</a>
        <a href="products.html" class="active">Productos</a>
        <a href="postulaciones.html">Postulaciones</a>
        <a href="contact.html">Contacto</a>
        <a href="servidores.html">Servidores</a>
      </nav>
    </header>
    <main>
      <section class="card">
        <h2>Productos</h2>
        <ul>
          <li><strong>Fotocopias</strong>: apuntes, guías, parciales, anillados.</li>
          <li><strong>Kiosco</strong>: bebidas, snacks, golosinas.</li>
          <li><strong>Librería</strong>: hojas, resmas, carpetas, biromes, resaltadores.</li>
        </ul>
        <a class="cta" href="index.html">Volver al inicio</a>
      </section>
    </main>
    <footer class="footer">© 2025 Kiosco y Fotocopiadora - Facultad de Ingeniería UNER</footer>
  </div>
</body>
</html>
"""

# --- Página: POSTULACIONES ---
postulaciones_html = """<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Postulaciones — Kiosco y Fotocopiadora FI-UNER</title>
  <link rel="stylesheet" href="assets/styles.css">
</head>
<body>
  <div class="container">
    <header class="header">
      <div class="brand">
        <img class="logo-img" src="assets/logo.png" alt="Kiosco y Fotocopiadora">
        <div>
          <h1 style="font-size:1.15rem;margin-bottom:2px">Kiosco y Fotocopiadora</h1>
          <div class="small">Facultad de Ingeniería UNER</div>
        </div>
      </div>
      <nav class="nav" aria-label="Navegación principal">
        <a href="index.html">Inicio</a>
        <a href="products.html">Productos</a>
        <a href="postulaciones.html" class="active">Postulaciones</a>
        <a href="contact.html">Contacto</a>
        <a href="servidores.html">Servidores</a>
      </nav>
    </header>
    <main>
      <section class="card">
        <h2>Postulá tu CV</h2>
        <p class="small">Completá el formulario y nos pondremos en contacto.</p>
        <form action="#" onsubmit="alert('Postulación enviada (😉)');return false;">
          <input type="text" placeholder="Nombre y apellido" required><br><br>
          <input type="email" placeholder="Email" required><br><br>
          <button class="cta" type="submit">Enviar</button>
        </form>
        <a class="cta" href="index.html">Volver al inicio</a>
      </section>
    </main>
    <footer class="footer">© 2025 Kiosco y Fotocopiadora - Facultad de Ingeniería UNER</footer>
  </div>
</body>
</html>
"""

# --- Página: CONTACTO ---
contact_html = """<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Contacto — Kiosco y Fotocopiadora FI-UNER</title>
  <link rel="stylesheet" href="assets/styles.css">
</head>
<body>
  <div class="container">
    <header class="header">
      <div class="brand">
        <img class="logo-img" src="assets/logo.png" alt="Kiosco y Fotocopiadora">
        <div>
          <h1 style="font-size:1.15rem;margin-bottom:2px">Kiosco y Fotocopiadora</h1>
          <div class="small">Facultad de Ingeniería UNER</div>
        </div>
      </div>
      <nav class="nav" aria-label="Navegación principal">
        <a href="index.html">Inicio</a>
        <a href="products.html">Productos</a>
        <a href="postulaciones.html">Postulaciones</a>
        <a href="contact.html" class="active">Contacto</a>
        <a href="servidores.html">Servidores</a>
      </nav>
    </header>
    <main>
      <section class="card">
        <h2>Contacto</h2>
        <ul>
          <li><strong>Email:</strong> <a href="mailto:quioscoyfotocopiadora@gmail.com">quioscoyfotocopiadora@gmail.com</a></li>
          <li><strong>Celular:</strong> <a href="tel:+5493434299432">+54 9 3434-299432</a></li>
        </ul>
        <p class="small">También podés acercarte al local en RP11, Oro Verde, Entre Ríos. Horario: 08:00 a 19:00 hs.</p>
        <a class="cta" href="index.html">Volver al inicio</a>
      </section>
    </main>
    <footer class="footer">© 2025 Kiosco y Fotocopiadora - Facultad de Ingeniería UNER</footer>
  </div>
</body>
</html>
"""

# --- Página: SERVIDORES ---
servidores_html = """<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Servidores — Kiosco y Fotocopiadora FI-UNER</title>
  <link rel="stylesheet" href="assets/styles.css">
  <style>
    table{width:100%;border-collapse:collapse}
    th,td{padding:10px;border:1px solid #334155;text-align:left;vertical-align:top}
    th{background:#0f172a}
    code{word-break:break-all}
    .muted{opacity:.8}
  </style>
</head>
<body>
  <div class="container">
    <header class="header">
      <div class="brand">
        <img class="logo-img" src="assets/logo.png" alt="Kiosco y Fotocopiadora">
        <div>
          <h1 style="font-size:1.15rem;margin-bottom:2px">Kiosco y Fotocopiadora</h1>
          <div class="small">Facultad de Ingeniería UNER</div>
        </div>
      </div>
      <nav class="nav" aria-label="Navegación principal">
        <a href="index.html">Inicio</a>
        <a href="products.html">Productos</a>
        <a href="postulaciones.html">Postulaciones</a>
        <a href="contact.html">Contacto</a>
        <a href="servidores.html" class="active">Servidores</a>
      </nav>
    </header>

    <main>
      <section class="card">
        <h2>Comparativa de encabezados: fetch() vs cURL</h2>
        <p class="small">Se consultan 5 endpoints públicos. A la izquierda, resultados en vivo con <code>fetch()</code>. A la derecha, los obtenidos con <code>cURL</code> (archivo <code>assets/curl_results.json</code> generado por script).</p>
        <div id="status" class="small">Cargando…</div>
        <div id="tabla"></div>
        <p class="small muted">Nota: Desde el navegador, solo se pueden leer headers expuestos por CORS. cURL puede ver más encabezados (no restringidos por CORS).</p>
      </section>
    </main>

    <footer class="footer">© 2025 Kiosco y Fotocopiadora - Facultad de Ingeniería UNER</footer>
  </div>

  <script>
  // mismos 5 servidores usados por fetch() y por el script de cURL
  const TARGETS = [
    { name: "GitHub API", url: "https://api.github.com/" },
    { name: "JSONPlaceholder", url: "https://jsonplaceholder.typicode.com/todos/1" },
    { name: "HTTPBin", url: "https://httpbin.org/get" },
    { name: "PokeAPI", url: "https://pokeapi.co/api/v2/pokemon/ditto" },
    { name: "CatFact", url: "https://catfact.ninja/fact" }
  ];

  const COMMON = ["content-type","cache-control","etag","date","server","x-ratelimit-limit","x-ratelimit-remaining","access-control-allow-origin"];

  const headersToObj = (headers) => {
    const o = {};
    headers.forEach((v,k)=> o[k] = v);
    return o;
  };

  async function fetchHeaders(target){
    const t0 = performance.now();
    try{
      const res = await fetch(target.url, { method: "GET" });
      const ms = Math.round(performance.now() - t0);
      const hdrs = headersToObj(res.headers);
      return { ok: true, name: target.name, url: target.url, ms, headers: hdrs, status: res.status };
    }catch(err){
      return { ok: false, name: target.name, url: target.url, error: String(err) };
    }
  }

  function renderKV(obj){
    if(!obj || !Object.keys(obj).length) return "<em class='small'>Sin headers legibles</em>";
    return Object.entries(obj).map(([k,v]) => `<div><strong>${k}:</strong> <code>${v}</code></div>`).join("");
  }

  function pickCommon(h){
    if(!h) return {};
    const out = {};
    COMMON.forEach(k => { if(h[k] !== undefined) out[k] = h[k]; });
    return out;
  }

  function byName(arr){
    const m = new Map();
    (arr || []).forEach(x => m.set(x.name, x));
    return m;
  }

  function renderTable(fetchRes, curlRes){
    const curlMap = byName(curlRes);
    const rows = fetchRes.map(fr => {
      const cr = curlMap.get(fr.name);
      const left = fr.ok
        ? `<div class="small">Status: ${fr.status} • ${fr.ms} ms</div>
           <div>${renderKV(pickCommon(fr.headers))}</div>`
        : `<div class="small">Error: ${fr.error}</div>`;

      const right = (cr && cr.ok)
        ? `<div class="small">Status: ${cr.status} • ${cr.ms ?? "—"} ms</div>
           <div>${renderKV(pickCommon(cr.headers))}</div>`
        : `<div class="small">${cr ? ("Error: "+(cr.error||"desconocido")) : "Sin datos cURL (genere curl_results.json)"}</div>`;

      return `<tr>
        <td>
          <strong>${fr.name}</strong>
          <div class="small"><code>${fr.url}</code></div>
        </td>
        <td>${left}</td>
        <td>${right}</td>
      </tr>`;
    }).join("");

    document.getElementById("tabla").innerHTML = `
      <table>
        <thead>
          <tr>
            <th>Servidor</th>
            <th>fetch() — headers comunes</th>
            <th>cURL — headers comunes</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>`;
  }

  (async () => {
    document.getElementById("status").textContent = "Consultando con fetch() y cargando resultados cURL…";

    const [fetchSide, curlSide] = await Promise.all([
      Promise.all(TARGETS.map(fetchHeaders)),
      fetch("assets/curl_results.json").then(r => r.json()).catch(() => null)
    ]);

    renderTable(fetchSide, curlSide || []);
    document.getElementById("status").textContent = "Listo.";
  })();
  </script>
</body>
</html>
"""


# --- Guardar archivos ---
(Path(BASE) / "assets" / "styles.css").write_text(CSS, encoding="utf-8")
(Path(BASE) / "index.html").write_text(index_html, encoding="utf-8")
(Path(BASE) / "products.html").write_text(products_html, encoding="utf-8")
(Path(BASE) / "postulaciones.html").write_text(postulaciones_html, encoding="utf-8")
(Path(BASE) / "contact.html").write_text(contact_html, encoding="utf-8")
(Path(BASE) / "servidores.html").write_text(servidores_html, encoding="utf-8")


print(f"Sitio generado en: {BASE.resolve()}")
