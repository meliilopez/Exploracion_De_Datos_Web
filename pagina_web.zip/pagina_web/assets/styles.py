from pathlib import Path

CSS = """body{font-family:sans-serif;background:#0f172a;color:#e6eef8;padding:20px}
.nav a{margin:0 10px;color:#94a3b8;text-decoration:none}
.nav a.active{color:#fff}
.card{padding:20px;background:#1e293b;border-radius:10px;margin:20px 0}
.cta{display:inline-block;margin-top:10px;padding:10px;background:#f97316;color:#fff;border-radius:6px;text-decoration:none}
"""

def write_css(dest_dir="sitio_multi_pagina"):
    d = Path(dest_dir)
    d.mkdir(parents=True, exist_ok=True)
    (d / "styles.css").write_text(CSS, encoding="utf-8")
    print(f"CSS escrito en: {(d/'styles.css').resolve()}")

if __name__ == "__main__":
    write_css()
